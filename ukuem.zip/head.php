<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
    <!--===============================================================================================-->	
	<title>ZEPS-Zanzibar Enviroment Permit System.</title>
	<link rel="icon" href="dashboard/assets/images/favicon.png" sizes="16x16" type="image/png">
    <!-- Your meta tags and stylesheets here -->
    <link rel="stylesheet" href="./css/toast.css">
    <link rel="stylesheet" href="./css/style.css">

</head>