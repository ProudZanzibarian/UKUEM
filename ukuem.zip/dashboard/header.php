<!doctype html>
<html lang="en">

<!-- Mirrored from demo.bosathemes.com/html/travele/admin/dashboard.html by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 21 Aug 2023 09:02:40 GMT -->

<head>
      <!-- Required meta tags -->
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <!--===============================================================================================-->
      <title>UKUEM</title>
      <link rel="icon" href="images/favicon.png" sizes="16x16" type="image/png">
      <!-- Bootstrap CSS -->
      <link rel="stylesheet" href="../assets/css/bootstrap.min.css"> 
      <!-- Fonts Awesome CSS -->
      <link rel="stylesheet" type="text/css" href="../assets/css/all.min.css">
      <!-- google fonts -->
      <link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,600;0,700;0,800;1,400&amp;family=Raleway:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,400&amp;display=swap" rel="stylesheet">
      <!-- Custom CSS -->
      <link rel="stylesheet" type="text/css" href="./style.css">
      <!-- toastr CSS -->
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css">
      <!-- Font Awesome -->
      <!-- <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.2/css/fontawesome.min.css"> -->

      <title>UKUEM</title>
</head>

<body>