<?php
// session_start();
// include "./session.php";
include("./header.php");
include("./nav.php") ?>
<div class="db-info-wrap">
    <div class="row">
        <div class="col-lg-12">
            <div class="dashboard-box table-opp-color-box">
                <h4>User Details</h4>
                <p>Airtport Hotels The Right Way To Start A Short Break Holiday</p>
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>User</th>
                                <th>Name</th>
                                <th>Phone</th>
                                <th>Email</th>
                                <th>Country</th>
                                <th>Operation</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td><span class="list-img"><img src="assets/images/comment.jpg" alt=""></span>
                                </td>
                                <td><a href="#"><span class="list-name">Kathy Brown</span></a>
                                </td>
                                <td>+01 3214 6522</td>
                                <td><a href="https://demo.bosathemes.com/cdn-cgi/l/email-protection" class="__cf_email__" data-cfemail="7f1c171e1b1a1118131a3f1b0a121206511c1012">[email&#160;protected]</a></td>
                                <td>Australia</td>
                                <td>
                                    <span class="badge badge-success">Confirm</span>
                                    <span class="badge badge-danger">Reject</span>
                                </td>
                            </tr>
                            <tr>
                                <td><span class="list-img"><img src="assets/images/comment2.jpg" alt=""></span>
                                </td>
                                <td><a href="#"><span class="list-name">Kathy Brown</span></a>
                                </td>
                                <td>+01 3214 6522</td>
                                <td><a href="https://demo.bosathemes.com/cdn-cgi/l/email-protection" class="__cf_email__" data-cfemail="13707b7277767d747f765377667e7e6a3d707c7e">[email&#160;protected]</a></td>
                                <td>Australia</td>
                                <td>
                                    <span class="badge badge-success">Confirm</span>
                                    <span class="badge badge-danger">Reject</span>
                                </td>
                            </tr>
                            <tr>
                                <td><span class="list-img"><img src="assets/images/comment3.jpg" alt=""></span>
                                </td>
                                <td><a href="#"><span class="list-name">Kathy Brown</span></a>
                                </td>
                                <td>+01 3214 6522</td>
                                <td><a href="https://demo.bosathemes.com/cdn-cgi/l/email-protection" class="__cf_email__" data-cfemail="4e2d262f2a2b2029222b0e2a3b232337602d2123">[email&#160;protected]</a></td>
                                <td>Australia</td>
                                <td>
                                    <span class="badge badge-success">Confirm</span>
                                    <span class="badge badge-danger">Reject</span>
                                </td>
                            </tr>
                            <tr>
                                <td><span class="list-img"><img src="assets/images/comment4.jpg" alt=""></span>
                                </td>
                                <td><a href="#"><span class="list-name">Kathy Brown</span></a>
                                </td>
                                <td>+01 3214 6522</td>
                                <td><a href="https://demo.bosathemes.com/cdn-cgi/l/email-protection" class="__cf_email__" data-cfemail="02616a6366676c656e674266776f6f7b2c616d6f">[email&#160;protected]</a></td>
                                <td>Australia</td>
                                <td>
                                    <span class="badge badge-success">Confirm</span>
                                    <span class="badge badge-danger">Reject</span>
                                </td>
                            </tr>
                            <tr>
                                <td><span class="list-img"><img src="assets/images/comment5.jpg" alt=""></span>
                                </td>
                                <td><a href="#"><span class="list-name">Kathy Brown</span></a>
                                </td>
                                <td>+01 3214 6522</td>
                                <td><a href="https://demo.bosathemes.com/cdn-cgi/l/email-protection" class="__cf_email__" data-cfemail="3053585154555e575c557054455d5d491e535f5d">[email&#160;protected]</a></td>
                                <td>Australia</td>
                                <td>
                                    <span class="badge badge-success">Confirm</span>
                                    <span class="badge badge-danger">Reject</span>
                                </td>
                            </tr>
                            <tr>
                                <td><span class="list-img"><img src="assets/images/comment6.jpg" alt=""></span>
                                </td>
                                <td><a href="#"><span class="list-name">Kathy Brown</span></a>
                                </td>
                                <td>+01 3214 6522</td>
                                <td><a href="https://demo.bosathemes.com/cdn-cgi/l/email-protection" class="__cf_email__" data-cfemail="492a21282d2c272e252c092d3c242430672a2624">[email&#160;protected]</a></td>
                                <td>Australia</td>
                                <td>
                                    <span class="badge badge-success">Confirm</span>
                                    <span class="badge badge-danger">Reject</span>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Content / End -->
<?php include("./footer.php"); ?>