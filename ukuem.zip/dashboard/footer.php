            <!-- Content / End -->
            <!-- Copyrights -->
            <div class="copyrights">
                Copyright © 2023 <a href="http://"></a>. All rights reserveds.
            </div>
            </div>
            <!-- Dashboard / End -->
            </div>
            <!-- end Container Wrapper -->
            <!-- *Scripts* -->
            <script data-cfasync="false" src="../../../cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script>
            <script src="../assets/js/jquery-3.2.1.min.js"></script>
            <script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/jquery.validate.min.js"></script>
            <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
            <script src="../assets/js/bootstrap.min.js"></script>
            <script src="../assets/js/canvasjs.min.js"></script>
            <script src="./assets/js/chart.js"></script>
            <script src="../assets/js/counterup.min.js"></script>
            <script src="../assets/js/jquery.slicknav.js"></script>
            <script src="../assets/js/dashboard-custom.js"></script>
            <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
            <script src="../assets/js/script.js"></script>


            </body>

            <!-- Mirrored from demo.bosathemes.com/html/travele/admin/dashboard.html by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 21 Aug 2023 09:03:08 GMT -->

            </html>